package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"golang.org/x/oauth2"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/credentials/oauth"
	"google.golang.org/grpc/encoding/gzip"
	"google.golang.org/grpc/keepalive"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/types/known/anypb"
	"google.golang.org/protobuf/types/known/timestamppb"
	pb "grpc/feature/proto"
	"io"
	"io/ioutil"
	"log"
	"time"
)

const fallbackToken = "some-secret-token"

var (
	addr = flag.String("addr", "localhost:50051", "the address to connect to")
)

func main() {
	log.SetFlags(log.Llongfile)
	flag.Parse()
	conn, err := grpc.Dial(*addr, getOptions()...)
	if err != nil {
		log.Fatalln(err)
		return
	}
	defer conn.Close()
	c := pb.NewGreeterClient(conn)
	sayHello(c)
	//sayHelloClientStream(c)
	//sayHelloServerStream(c)
	sayHelloTwoWayStream(c)

}
func getHelloRequest(name ...string) *pb.HelloRequest {
	t, _ := time.Parse("2006-01-02 15:04:05Z07:00", "2002-05-05 16:00:00+08:00")
	birthday := timestamppb.New(t)
	any1, _ := anypb.New(birthday)
	any2, _ := anypb.New(&pb.Address{
		Province: "湖北",
		City:     "武汉",
	})
	in := &pb.HelloRequest{
		Name:     "nick",
		Gender:   pb.Gender_MALE,
		Age:      18,
		Birthday: birthday,
		Addr: &pb.Address{
			Province: "湖南",
			City:     "长沙",
		},
		Hobys: []string{"篮球", "羽毛球"},
		Data: map[string]*anypb.Any{
			"A": any1,
			"B": any2,
		},
	}
	if len(name) > 0 {
		in.Name = name[0]
	}
	return in
}

func getMetadata() metadata.MD {
	//创建元数据对象
	md := metadata.New(map[string]string{"time": time.Now().Format("2006-01-02T15:04:05Z07:00"), "serverName": "feature"})
	return md
}
func sayHello(c pb.GreeterClient) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	md := getMetadata()
	//将元数据覆盖写入到ctx,New方法会覆盖原有元数据
	ctx = metadata.NewOutgoingContext(ctx, md)

	//定义头部与尾部元数据接收对象
	var header, trailer metadata.MD
	in := getHelloRequest()
	//添加压缩选项
	r, err := c.SayHello(ctx, in, grpc.UseCompressor(gzip.Name), grpc.Header(&header), grpc.Trailer(&trailer))
	if err != nil {
		log.Println(err)
		return
	}
	fmt.Println(r.Message)
	fmt.Printf("client recv metadata head metadata:%+v\n", header)
	fmt.Printf("client recv metadata trailer metadata:%+v\n", trailer)
}

func sayHelloClientStream(c pb.GreeterClient) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()
	md := getMetadata()
	//将元数据覆盖写入到ctx,New方法会覆盖原有元数据
	ctx = metadata.NewOutgoingContext(ctx, md)
	list := []*pb.HelloRequest{
		getHelloRequest("nick1"), getHelloRequest("nick2"), getHelloRequest("nick3"), getHelloRequest("nick4"), getHelloRequest("nick5"),
	}
	stream, err := c.SayHelloClientStream(ctx)
	if err != nil {
		log.Fatalln(err)
		return
	}

	//获取头部
	header, _ := stream.Header()
	fmt.Printf("client recv metadata head metadata:%+v\n", header)

	for _, in := range list {
		err := stream.Send(in)
		if err != nil {
			log.Println(err)
			return
		}
	}
	reply, err := stream.CloseAndRecv()
	//尾部元数据获取
	trailer := stream.Trailer()
	fmt.Printf("client recv metadata trailer metadata:%+v\n", trailer)

	if err != nil {
		log.Println(err)
		return
	}
	fmt.Printf("client recv: %+v\n", reply)
}

func sayHelloServerStream(c pb.GreeterClient) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	md := getMetadata()
	//将元数据覆盖写入到ctx,New方法会覆盖原有元数据
	ctx = metadata.NewOutgoingContext(ctx, md)
	stream, err := c.SayHelloServerStream(ctx, getHelloRequest())
	if err != nil {
		log.Println(err)
		return
	}
	header, _ := stream.Header()
	fmt.Printf("client recv metadata head metadata:%+v\n", header)

	var rpcErr error
	for {
		reply, err := stream.Recv()
		rpcErr = err
		if err == io.EOF {
			break
		}
		fmt.Printf("client recv : %+v\n", reply)
	}
	if rpcErr != io.EOF {
		log.Fatalln(rpcErr)
	}
	stream.CloseSend()

	trailer := stream.Trailer()
	fmt.Printf("client recv metadata trailer metadata:%+v\n", trailer)
}

func sayHelloTwoWayStream(c pb.GreeterClient) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	ctx = metadata.NewOutgoingContext(ctx, getMetadata())
	list := []*pb.HelloRequest{
		getHelloRequest("nick1"), getHelloRequest("nick2"), getHelloRequest("nick3"), getHelloRequest("nick4"), getHelloRequest("nick5"),
	}
	stream, err := c.SayHelloTwoWayStream(ctx)
	if err != nil {
		log.Println(err)
		return
	}
	var done = make(chan struct{}, 0)
	go func() {
		for {
			reply, err := stream.Recv()
			if err == io.EOF {
				close(done)
				return
			}
			if err != nil {
				close(done)
				log.Println(err)
				return
			}
			fmt.Printf("client recv: %+v\n", reply)
		}
	}()
	header, _ := stream.Header()
	fmt.Printf("client recv metadata head metadata:%+v\n", header)
	for _, req := range list {
		err := stream.Send(req)
		if err != nil {
			log.Println(err)
			return
		}
	}
	//何时关闭流，请根据具体业务场景设计
	stream.CloseSend()
	<-done
	trailer := stream.Trailer()
	fmt.Printf("client recv metadata trailer metadata:%+v\n", trailer)
}

func getOptions() (opts []grpc.DialOption) {
	opts = make([]grpc.DialOption, 0)
	//	opts = append(opts, getTlsOpt())
	opts = append(opts, getMlsOpt())
	//opts = append(opts, getOauth2Opt())
	opts = append(opts, getUnaryInterceptor())
	opts = append(opts, getStreamInterceptor())
	opts = append(opts, getKeepaliveOpt())
	return
}
func getTlsOpt() (opt grpc.DialOption) {
	creds, err := credentials.NewClientTLSFromFile("feature/x509/ca_cert.pem", "x.test.example.com")
	if err != nil {
		log.Fatalln(err)
	}
	opt = grpc.WithTransportCredentials(creds)
	return
}
func getMlsOpt() (opt grpc.DialOption) {
	cert, err := tls.LoadX509KeyPair("feature/x509/client_cert.pem", "feature/x509/client_key.pem")
	if err != nil {
		log.Fatalln(err)
		return
	}
	ca := x509.NewCertPool()
	caFilePath := "feature/x509/ca_cert.pem"
	caBytes, err := ioutil.ReadFile(caFilePath)
	if err != nil {
		log.Fatalln(err)
	}
	if ok := ca.AppendCertsFromPEM(caBytes); !ok {
		log.Fatalln("ca append failed")
	}
	tlsConfig := &tls.Config{
		ServerName:   "x.test.example.com",
		Certificates: []tls.Certificate{cert},
		RootCAs:      ca,
	}
	return grpc.WithTransportCredentials(credentials.NewTLS(tlsConfig))
}

func getOauth2Opt() (opt grpc.DialOption) {
	opt = grpc.WithPerRPCCredentials(oauth.NewOauthAccess(&oauth2.Token{
		AccessToken: fallbackToken,
	}))
	return
}

func getUnaryInterceptor() (opt grpc.DialOption) {
	opt = grpc.WithUnaryInterceptor(unaryClientInterceptor)
	return opt
}
func getStreamInterceptor() (opt grpc.DialOption) {
	opt = grpc.WithStreamInterceptor(streamClientInterceptor)
	return opt
}

func unaryClientInterceptor(ctx context.Context, method string, req, reply interface{}, cc *grpc.ClientConn, invoker grpc.UnaryInvoker, opts ...grpc.CallOption) error {
	var credsConfigured bool
	for _, opt := range opts {
		_, ok := opt.(grpc.PerRPCCredsCallOption)
		if ok {
			credsConfigured = true
			break
		}
	}
	if !credsConfigured {
		opt := grpc.PerRPCCredentials(oauth.NewOauthAccess(&oauth2.Token{
			AccessToken: fallbackToken,
		}))
		opts = append(opts, opt)
	}
	return invoker(ctx, method, req, reply, cc, opts...)
}
func streamClientInterceptor(ctx context.Context, desc *grpc.StreamDesc, cc *grpc.ClientConn, method string, streamer grpc.Streamer, opts ...grpc.CallOption) (grpc.ClientStream, error) {
	var credsConfigured bool
	for _, opt := range opts {
		_, ok := opt.(grpc.PerRPCCredsCallOption)
		if ok {
			credsConfigured = true
			break
		}
	}
	if !credsConfigured {
		opt := grpc.PerRPCCredentials(oauth.NewOauthAccess(&oauth2.Token{
			AccessToken: fallbackToken,
		}))
		opts = append(opts, opt)
	}
	s, err := streamer(ctx, desc, cc, method, opts...)
	return s, err
}
func getKeepaliveOpt() (opt grpc.DialOption) {

	var kacp = keepalive.ClientParameters{
		Time:                10 * time.Second, // send pings every 10 seconds if there is no activity
		Timeout:             time.Second,      // wait 1 second for ping ack before considering the connection dead
		PermitWithoutStream: true,             // send pings even without active streams
	}
	return grpc.WithKeepaliveParams(kacp)
}
