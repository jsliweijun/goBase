package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	_ "google.golang.org/grpc/encoding/gzip"
	"google.golang.org/grpc/keepalive"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	pb "grpc/feature/proto"
	"io"
	"io/ioutil"
	"log"
	"net"
	"strings"
	"time"
)

const fallbackToken = "some-secret-token"

var (
	port               = flag.Int("port", 50051, "The server port")
	errMissingMetadata = status.Errorf(codes.InvalidArgument, "missing metadata")
	errInvalidToken    = status.Errorf(codes.Unauthenticated, "invalid token")
)

type server struct {
	pb.UnimplementedGreeterServer
}

func getMetadata() (metadata.MD, metadata.MD) {

	trailer := metadata.Pairs("A", "B", "C", "D")
	header := metadata.New(map[string]string{"local": "en", "time": time.Now().Format("2006-01-02T15:04:05Z07:00")})
	return header, trailer
}

func (s *server) SayHello(ctx context.Context, in *pb.HelloRequest) (*pb.HelloReply, error) {
	header, trailer := getMetadata()
	defer func() {
		//发送尾部元数据
		grpc.SetTrailer(ctx, trailer)
	}()

	log.Printf("server recv: %+v\n", in)

	//接收元数据
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		log.Fatalln(" get metadata failed")
	}
	fmt.Printf("server recv metadata:%+v\n", md)

	//发送头部数据
	grpc.SendHeader(ctx, header)

	res := &pb.HelloReply{Message: in.String()}
	return res, nil
}

//客户端到服务端流
func (s *server) SayHelloClientStream(stream pb.Greeter_SayHelloClientStreamServer) error {
	header, trailer := getMetadata()
	defer func() {
		//发送尾部元数据
		stream.SetTrailer(trailer)
	}()

	md, _ := metadata.FromIncomingContext(stream.Context())
	fmt.Printf("server recv metadata:%+v\n", md)

	//发送头部数据
	stream.SendHeader(header)

	list := make([]*pb.HelloRequest, 0)
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			return stream.SendAndClose(&pb.HelloReply{
				Message: fmt.Sprintf("total recv count:%d ", len(list)),
			})
		}
		if err != nil {
			log.Println(err)
			return err
		}
		list = append(list, req)
		fmt.Printf("Server recv : %+v\n", req)
	}
}

func (s *server) SayHelloServerStream(in *pb.HelloRequest, stream pb.Greeter_SayHelloServerStreamServer) error {
	header, trailer := getMetadata()
	defer func() {
		//发送尾部元数据
		stream.SetTrailer(trailer)
	}()
	fmt.Printf("Server recv : %+v\n", in)
	md, _ := metadata.FromIncomingContext(stream.Context())
	fmt.Printf("server recv metadata:%+v\n", md)
	list := []pb.HelloReply{
		{
			Message: "1th message",
		},

		{
			Message: "2th message",
		},
		{
			Message: "3th message",
		},
		{
			Message: "4th message",
		},
		{
			Message: "5th message",
		},
	}
	stream.SendHeader(header)
	for _, reply := range list {
		err := stream.Send(&reply)
		if err != nil {
			log.Println(err)
		}
	}
	return nil
}

func (s *server) SayHelloTwoWayStream(stream pb.Greeter_SayHelloTwoWayStreamServer) error {
	header, trailer := getMetadata()
	defer func() {
		stream.SetTrailer(trailer)
	}()
	md, _ := metadata.FromIncomingContext(stream.Context())
	fmt.Printf("server recv metadata:%+v\n", md)

	stream.SendHeader(header)
	var i = 0
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		i++
		fmt.Printf("Server recv: %+v\n", req)
		stream.Send(&pb.HelloReply{
			Message: fmt.Sprintf("%dth request ok", i),
		})
	}
	return nil
}
func main() {
	flag.Parse()
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", *port))
	if err != nil {
		log.Fatal(err)
		return
	}
	s := grpc.NewServer(getOptions()...)
	pb.RegisterGreeterServer(s, &server{})
	log.Printf("server listening at %v ", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatal(err)
	}
}

func getOptions() (opts []grpc.ServerOption) {
	opts = make([]grpc.ServerOption, 0)
	//opts = append(opts, getTlsOpt())
	opts = append(opts, getMTlsOpt())
	opts = append(opts, getUnaryInterceptor())
	opts = append(opts, getStreamInterceptor())
	opts = append(opts, getKeepaliveOpt()...)
	return
}

//TLS
func getTlsOpt() (opt grpc.ServerOption) {
	creds, err := credentials.NewServerTLSFromFile("feature/x509/server_cert.pem", "feature/x509/server_key.pem")
	if err != nil {
		log.Fatalln(err)
		return
	}
	return grpc.Creds(creds)
}

//mTLS
func getMTlsOpt() (opt grpc.ServerOption) {
	cert, err := tls.LoadX509KeyPair("feature/x509/server_cert.pem", "feature/x509/server_key.pem")
	if err != nil {
		log.Fatalln(err)
		return
	}
	ca := x509.NewCertPool()
	caFilePath := "feature/x509/client_ca_cert.pem"
	caBytes, err := ioutil.ReadFile(caFilePath)
	if err != nil {
		log.Fatalln(err)
	}
	if ok := ca.AppendCertsFromPEM(caBytes); !ok {
		log.Fatalln("ca append failed")
	}
	tlsConfig := &tls.Config{
		ClientAuth:   tls.RequireAndVerifyClientCert,
		Certificates: []tls.Certificate{cert},
		ClientCAs:    ca,
	}
	return grpc.Creds(credentials.NewTLS(tlsConfig))
}

func getUnaryInterceptor() (opt grpc.ServerOption) {
	opt = grpc.UnaryInterceptor(unaryInterceptor)
	return opt
}
func getStreamInterceptor() (opt grpc.ServerOption) {
	opt = grpc.StreamInterceptor(streamInterceptor)
	return opt
}

func valid(authorization []string) bool {
	if len(authorization) < 1 {
		return false
	}
	token := strings.TrimPrefix(authorization[0], "Bearer ")
	return token == fallbackToken
}
func unaryInterceptor(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return nil, errMissingMetadata
	}
	if !valid(md["authorization"]) {
		return nil, errInvalidToken
	}
	m, err := handler(ctx, req)
	if err != nil {
		log.Println(err)
	}
	return m, err
}
func streamInterceptor(srv interface{}, ss grpc.ServerStream, info *grpc.StreamServerInfo, handler grpc.StreamHandler) error {
	md, ok := metadata.FromIncomingContext(ss.Context())
	if !ok {
		return errMissingMetadata
	}
	if !valid(md["authorization"]) {
		return errInvalidToken
	}
	return handler(srv, ss)
}
func getKeepaliveOpt() (opt []grpc.ServerOption) {

	var kaep = keepalive.EnforcementPolicy{
		//客户端ping服务器，最小时间间隔，小于该时间间隔强制关闭连接
		MinTime: 5 * time.Second, // If a client pings more than once every 5 seconds, terminate the connection
		//当没有任何活动流的情况下，是否允许被ping
		PermitWithoutStream: true, // Allow pings even when there are no active streams
	}

	var kasp = keepalive.ServerParameters{
		//客户端空闲15秒发送goaway指令（尝试断开连接）
		MaxConnectionIdle: 15 * time.Second, // If a client is idle for 15 seconds, send a GOAWAY
		//最大连接时长30s,超时发送goaway
		MaxConnectionAge: 30 * time.Second, // If any connection is alive for more than 30 seconds, send a GOAWAY
		//强制关闭前等待时长
		MaxConnectionAgeGrace: 5 * time.Second, // Allow 5 seconds for pending RPCs to complete before forcibly closing connections
		//客户端空闲5秒，发送ping保活
		Time: 5 * time.Second, // Ping the client if it is idle for 5 seconds to ensure the connection is still active
		//ping ack 1s内没有返回则认定为连接断开
		Timeout: 1 * time.Second, // Wait 1 second for the ping ack before assuming the connection is dead
	}
	return []grpc.ServerOption{grpc.KeepaliveEnforcementPolicy(kaep), grpc.KeepaliveParams(kasp)}
}
