package main

import (
	"context"
	"flag"
	"fmt"
	"google.golang.org/grpc"
	_ "google.golang.org/grpc/encoding/gzip"
	pb "grpc/stream/proto"
	"io"
	"log"
	"net"
)

var (
	port = flag.Int("port", 50051, "The server port")
)

type server struct {
	pb.UnimplementedGreeterServer
}

func (s *server) SayHello(ctx context.Context, in *pb.HelloRequest) (*pb.HelloReply, error) {
	log.Printf("server recv: %+v\n", in)
	return &pb.HelloReply{Message: in.String()}, nil
}

//客户端到服务端流
func (s *server) SayHelloClientStream(stream pb.Greeter_SayHelloClientStreamServer) error {
	list := make([]*pb.HelloRequest, 0)
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			return stream.SendAndClose(&pb.HelloReply{
				Message: fmt.Sprintf("total recv count:%d ", len(list)),
			})
		}
		if err != nil {
			log.Println(err)
			return err
		}
		list = append(list, req)
		fmt.Printf("Server recv : %+v\n", req)
	}
}

func (s *server) SayHelloServerStream(in *pb.HelloRequest, stream pb.Greeter_SayHelloServerStreamServer) error {
	fmt.Printf("Server recv : %+v\n", in)
	list := []pb.HelloReply{
		{
			Message: "1th message",
		},

		{
			Message: "2th message",
		},
		{
			Message: "3th message",
		},
		{
			Message: "4th message",
		},
		{
			Message: "5th message",
		},
	}
	for _, reply := range list {
		err := stream.Send(&reply)
		if err != nil {
			log.Println(err)
		}
	}
	return nil
}

func (s *server) SayHelloTwoWayStream(stream pb.Greeter_SayHelloTwoWayStreamServer) error {
	var i = 0
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		i++
		fmt.Printf("Server recv: %+v\n", req)
		stream.Send(&pb.HelloReply{
			Message: fmt.Sprintf("%dth request ok", i),
		})
	}
	return nil
}
func main() {
	flag.Parse()
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", *port))
	if err != nil {
		log.Fatal(err)
		return
	}
	s := grpc.NewServer()
	pb.RegisterGreeterServer(s, &server{})
	log.Printf("server listening at %v ", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatal(err)
	}
}
