package main

import (
	"context"
	"flag"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/encoding/gzip"
	anypb "google.golang.org/protobuf/types/known/anypb"
	"google.golang.org/protobuf/types/known/timestamppb"
	pb "grpc/helloworld/proto"
	"log"
	"time"
)

var (
	addr = flag.String("addr", "localhost:50051", "the address to connect to")
)

func main() {
	flag.Parse()
	conn, err := grpc.Dial(*addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalln(err)
		return
	}
	defer conn.Close()

	c := pb.NewGreeterClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	t, _ := time.Parse("2006-01-02 15:04:05Z07:00", "2002-05-05 16:00:00+08:00")
	birthday := timestamppb.New(t)
	any1, _ := anypb.New(birthday)
	any2, _ := anypb.New(&pb.Address{
		Province: "湖北",
		City:     "武汉",
	})
	in := &pb.HelloRequest{
		Name:     "nick",
		Gender:   pb.Gender_MALE,
		Age:      18,
		Birthday: birthday,
		Addr: &pb.Address{
			Province: "湖南",
			City:     "长沙",
		},
		Hobys: []string{"篮球", "羽毛球"},
		Data: map[string]*anypb.Any{
			"A": any1,
			"B": any2,
		},
	}
	//添加压缩选项
	r, err := c.SayHello(ctx, in, grpc.UseCompressor(gzip.Name))
	if err != nil {
		log.Println(err)
		return
	}
	log.Println(r.Message)
}
