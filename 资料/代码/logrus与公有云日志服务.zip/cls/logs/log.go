package logs

import "github.com/sirupsen/logrus"

const LOGPATH = "runtime/logs/cos.log"

var adapters = make(map[string]*Log, 0)

type Log struct {
	*logrus.Entry
	LogWriter
}

func (l *Log) Flush() {
	l.LogWriter.Flush()
}

func registerAdapter(adapterName string, log *Log) {
	adapters[adapterName] = log
}

type LogConf struct {
	Level       logrus.Level
	AdapterName string
}

func InitLog(conf LogConf) *Log {
	adapterName := "std"
	if conf.AdapterName != "" {
		adapterName = conf.AdapterName
	}
	entry, ok := adapters[adapterName]
	log := entry.Logger
	if !ok {
		panic("未找到对应的log对象")
	}
	if conf.Level != 0 {
		log.SetLevel(conf.Level)
	}
	log.SetReportCaller(true)
	return entry
}
