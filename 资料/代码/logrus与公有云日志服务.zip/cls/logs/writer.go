package logs

import "io"

type LogWriter interface {
	Flush()
	io.Writer
}
