package logs

import (
	"cls/config"
	"encoding/json"
	"fmt"
	"github.com/sirupsen/logrus"
	cls "github.com/tencentcloud/tencentcloud-cls-sdk-go"
	"log"
	"strconv"
	"time"
)

type clsWriter struct {
	ClsClient *cls.AsyncProducerClient
}

func (cw *clsWriter) Write(p []byte) (int, error) {
	mp := make(map[string]string)
	tmp := make(map[string]interface{})
	err := json.Unmarshal(p, &tmp)
	if err != nil {
		mp["content"] = string(p)
	} else {
		str, ok := tmp["__content__"].(string)
		if !ok {
			mp["content"] = string(p)
		} else {
			json.Unmarshal([]byte(str), &mp)
		}
	}
	cw.sendLog(mp)
	return len(p), nil
}
func (cw *clsWriter) Flush() {
	cw.ClsClient.Close(60000)
}

type clsHook struct {
}

func (hook *clsHook) Levels() []logrus.Level {
	return logrus.AllLevels
}
func (hook *clsHook) Fire(entity *logrus.Entry) error {
	mp := make(map[string]string)
	mp["file"] = entity.Caller.File + ":" + strconv.Itoa(entity.Caller.Line)
	mp["func"] = entity.Caller.Function
	mp["level"] = entity.Level.String()
	mp["msg"] = entity.Message
	mp["time"] = entity.Time.Format("2006-01-02T15:04:05Z7")
	fields, err := json.Marshal(entity.Data)
	if err == nil {
		mp["fields"] = string(fields)
	}
	bytes, _ := json.Marshal(mp)
	entity.Data["__content__"] = string(bytes)
	return nil
}

func newClsWriter() LogWriter {
	client, err := getClient()
	if err != nil {
		log.Fatalln(err)
	}
	writer := &clsWriter{
		ClsClient: client,
	}
	return writer
}
func getClient() (*cls.AsyncProducerClient, error) {
	producerConfig := cls.GetDefaultAsyncProducerClientConfig()
	producerConfig.Endpoint = config.Confs.GetString("Cls.Endpoint")
	producerConfig.AccessKeyID = config.Secrets.GetString("TencentCloudSecret.SecretId")
	producerConfig.AccessKeySecret = config.Secrets.GetString("TencentCloudSecret.SecretKey")
	producerInstance, err := cls.NewAsyncProducerClient(producerConfig)
	if err != nil {
		log.Fatalln(err)
	}
	producerInstance.Start()
	return producerInstance, err
}

func (cw *clsWriter) sendLog(msg map[string]string) {
	topicId := config.Confs.GetString("Cls.TopicId")
	log := cls.NewCLSLog(time.Now().Unix(), msg)
	callBack := &Callback{}
	err := cw.ClsClient.SendLog(topicId, log, callBack)
	if err != nil {
	}
}

type Callback struct {
}

func (callback *Callback) Success(result *cls.Result) {
	attemptList := result.GetReservedAttempts()
	fmt.Println(attemptList)
	for _, attempt := range attemptList {
		fmt.Printf("%+v \n", attempt)
	}
}

func (callback *Callback) Fail(result *cls.Result) {
	fmt.Println(result.IsSuccessful())
	fmt.Println(result.GetErrorCode())
	fmt.Println(result.GetErrorMessage())
	fmt.Println(result.GetReservedAttempts())
	fmt.Println(result.GetRequestId())
	fmt.Println(result.GetTimeStampMs())
}
func init() {
	entry := logrus.NewEntry(logrus.New())
	entry.Logger.SetFormatter(&logrus.JSONFormatter{})
	hook := &clsHook{}
	entry.Logger.AddHook(hook)
	log := &Log{
		entry,
		newClsWriter(),
	}
	log.Logger.SetOutput(log.LogWriter)
	registerAdapter("cls", log)
}
