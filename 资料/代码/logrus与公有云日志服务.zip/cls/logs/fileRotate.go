package logs

import (
	rotatelogs "github.com/lestrrat-go/file-rotatelogs"
	"github.com/sirupsen/logrus"
	"log"
	"time"
)

type fileRotateWriter struct {
	*rotatelogs.RotateLogs
}

func (frw *fileRotateWriter) Flush() {
	frw.Close()
}

func newFileRotateWriter() LogWriter {
	writer, err := getWriter()
	if err != nil {
		log.Println(err)
		return nil
	}
	return &fileRotateWriter{
		writer,
	}
}
func getWriter() (*rotatelogs.RotateLogs, error) {
	path := LOGPATH
	writer, err := rotatelogs.New(path+".%Y%m%d%H%M", //指定文件名格式
		//	rotatelogs.WithLinkName(path), //将最新文件软链到指定path ，windows环境不支持
		rotatelogs.WithMaxAge(time.Second*1800),     // 日志最长保存时长
		rotatelogs.WithRotationTime(time.Second*60)) //日志分割时间间隔
	return writer, err
}
func init() {
	entry := logrus.NewEntry(logrus.New())
	log := &Log{
		entry,
		newFileRotateWriter(),
	}
	log.Logger.SetOutput(log.LogWriter)
	registerAdapter("fileRotate", log)
}
