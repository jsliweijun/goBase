package logs

import (
	"github.com/sirupsen/logrus"
	"os"
)

type fileWriter struct {
	*os.File
}

func (s *fileWriter) Flush() {
	s.Sync()
}

func newFileWriter() LogWriter {
	file, err := os.OpenFile(LOGPATH, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0666)
	if err != nil {
		file = os.Stderr
	}
	return &fileWriter{
		file,
	}
}

func init() {
	entry := logrus.NewEntry(logrus.New())
	log := &Log{
		entry,
		newFileWriter(),
	}
	log.Logger.SetOutput(log.LogWriter)
	registerAdapter("file", log)
}
