package logs

import (
	"github.com/sirupsen/logrus"
	"os"
)

type stdWriter struct {
	*os.File
}

func (s *stdWriter) Flush() {
	s.Sync()
}

func newStdWriter() LogWriter {
	return &stdWriter{
		os.Stderr,
	}
}

func init() {
	entry := logrus.NewEntry(logrus.New())
	log := &Log{
		entry,
		newStdWriter(),
	}
	log.Logger.SetOutput(log.LogWriter)
	registerAdapter("std", log)
}
