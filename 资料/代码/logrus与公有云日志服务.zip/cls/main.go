package main

import (
	"cls/logs"
	"github.com/sirupsen/logrus"
)

func main() {

	cf := logs.LogConf{
		Level:       logrus.TraceLevel,
		AdapterName: "cls",
	}
	log := logs.InitLog(cf)
	log.Trace("Something very low level.")
	log.Debug("Useful debugging information.")
	log.Info("Something noteworthy happened!")
	log.Warn("You should probably take a look at this.")
	log.Error("Something failed but I'm not quitting.")
	// Calls os.Exit(1) after logging
	//log.Fatal("Bye.")
	// Calls panic() after logging
	//log.Panic("I'm bailing.")
	log.WithFields(logrus.Fields{
		"animal": "walrus",
		"number": 1,
		"size":   10,
	}).Info("A walrus appears")
	//log.Exit(1)
	//log.AddHook()

	log.Flush()
}
