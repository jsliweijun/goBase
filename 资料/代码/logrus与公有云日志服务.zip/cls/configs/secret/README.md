# 配置文件名称为：secrets.yaml
## 可从defaultConf/secret目录下复制默认配置文件
## 需要自行调整部分配置的值