package main

import (
	"fmt"
	dns_request "udp-dns/dns-request"
)

func main() {
	fmt.Println(dns_request.DigDomain("192.168.0.1:53", "www.baidu.com"))
}
