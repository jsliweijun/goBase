package cache

import (
	"fmt"
	"sync"
	"time"
)

type memCache struct {
	//最大内存
	maxMemorySizeStr string
	//最大内存对应的int64
	maxMemorySize int64
	//当前使用内存大小
	currMemorySize int64
	//缓存键值对值
	values map[string]*memCacheValue
	//读写锁
	locker sync.RWMutex
	//清除过期缓存时间间隔
	clearExpiredItemTimeInterval time.Duration
}
type memCacheValue struct {
	value interface{}
	//插入时间
	insertTime time.Time
	//有效时长
	expire time.Duration
	//value 大小
	size int64
}

func NewMemCache() Cache {
	_memCache := &memCache{
		values:                       make(map[string]*memCacheValue, 0),
		clearExpiredItemTimeInterval: time.Second,
	}
	go _memCache.clearExpiredItem()
	return _memCache
}

//设置缓存最大内存
func (mc *memCache) SetMaxMemory(size string) bool {
	mc.maxMemorySize, mc.maxMemorySizeStr = ParseSize(size)
	return true
}

//设置缓存，expire后过期
func (mc *memCache) Set(key string, val interface{}, expire time.Duration) bool {
	mc.locker.Lock()
	defer mc.locker.Unlock()
	valSize := GetValSize(val)
	mcv := &memCacheValue{
		value:      val,
		insertTime: time.Now(),
		expire:     expire,
		size:       valSize,
	}
	mc.del(key)
	mc.add(key, mcv)
	if mc.currMemorySize > mc.maxMemorySize {
		mc.del(key)
		panic(fmt.Sprintf("max memory size %s", mc.maxMemorySizeStr))
	}
	return true
}

//根据key获取元素
func (mc *memCache) Get(key string) (interface{}, bool) {
	mc.locker.RLock()
	defer mc.locker.RUnlock()
	mcv, ok := mc.get(key)
	if ok {
		//判定缓存是否过期，过期则删除该缓存项
		if mcv.expire != 0 && time.Now().After(mcv.insertTime.Add(mcv.expire)) {
			mc.del(key)
			return nil, false
		}
		return mcv.value, ok
	}
	return nil, false
}

//根据key删除元素
func (mc *memCache) Del(key string) bool {
	mc.locker.Lock()
	defer mc.locker.Unlock()
	mc.del(key)
	return true
}

//判断Key是否存在
func (mc *memCache) Exists(key string) bool {
	mc.locker.RLock()
	defer mc.locker.RUnlock()
	_, ok := mc.values[key]
	return ok
}

//清空所有缓存
func (mc *memCache) Flush() bool {
	mc.locker.Lock()
	defer mc.locker.Unlock()
	mc.values = make(map[string]*memCacheValue, 0)
	mc.currMemorySize = 0
	return true
}

//获取keys数量
func (mc *memCache) Keys() int64 {
	mc.locker.RLock()
	defer mc.locker.RUnlock()
	return int64(len(mc.values))
}

//清空过期缓存
func (mc *memCache) clearExpiredItem() {
	timeTicker := time.NewTicker(mc.clearExpiredItemTimeInterval)
	defer timeTicker.Stop()
	for {
		select {
		case <-timeTicker.C:
			for key, item := range mc.values {
				if item.expire != 0 && time.Now().After(item.insertTime.Add(item.expire)) {
					mc.locker.Lock()
					mc.del(key)
					mc.locker.Unlock()
				}
			}
		}
	}
}

func (mc *memCache) get(key string) (*memCacheValue, bool) {
	val, ok := mc.values[key]
	return val, ok
}

func (mc *memCache) add(key string, val *memCacheValue) {
	mc.values[key] = val
	mc.currMemorySize += val.size
}

func (mc *memCache) del(key string) {
	tmp, ok := mc.get(key)
	delete(mc.values, key)
	if ok && tmp != nil {
		mc.currMemorySize -= tmp.size
	}
}
