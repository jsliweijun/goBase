package cache_server

import (
	"memCache/cache"
	"time"
)

type cacheServer struct {
	mCache cache.Cache
}

func NewMemCache() *cacheServer {
	cache := &cacheServer{
		cache.NewMemCache(),
	}
	return cache
}
func (c *cacheServer) SetMaxMemory(size string) bool {
	c.mCache.SetMaxMemory(size)
	return true
}
func (c *cacheServer) Set(key string, val interface{}, expire ...time.Duration) {
	tmpExpire := 0 * time.Second
	if len(expire) > 0 {
		tmpExpire = expire[0]
	}
	c.mCache.Set(key, val, tmpExpire)
}

func (c *cacheServer) Get(key string) (interface{}, bool) {
	return c.mCache.Get(key)
}

func (c *cacheServer) Del(key string) bool {
	return c.mCache.Del(key)
}

func (c *cacheServer) Exists(key string) bool {
	return c.mCache.Exists(key)
}

func (c *cacheServer) Flush() bool {
	return c.mCache.Flush()
}

func (c *cacheServer) Keys() int64 {
	return c.mCache.Keys()
}
