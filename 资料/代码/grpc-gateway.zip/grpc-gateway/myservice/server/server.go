package main

import (
	"context"
	"flag"
	"fmt"
	"google.golang.org/grpc"
	pb "grpc-gateway/myservice/myservice"
	"log"
	"net"
)

type server struct {
	pb.UnimplementedMyServiceServer
}

func (s *server) Echo(ctx context.Context, in *pb.StringMessage) (*pb.StringMessage, error) {
	fmt.Printf("server recv %+v\n", in)
	return &pb.StringMessage{
		Value: "hhhhhhhh",
	}, nil
}

var (
	port = flag.Int("port", 50051, "")
)

func main() {
	flag.Parse()
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", *port))
	if err != nil {
		log.Fatalln(err)
		return
	}
	s := grpc.NewServer()
	pb.RegisterMyServiceServer(s, &server{})

	if err := s.Serve(lis); err != nil {
		log.Fatalln(err)
	}
}
