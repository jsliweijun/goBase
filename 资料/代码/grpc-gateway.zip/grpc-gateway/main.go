package main

import (
	"context"
	"flag"
	"fmt"
	"google.golang.org/grpc/metadata"
	pb "grpc-gateway/myservice2/myservice2"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/golang/glog"
	"github.com/grpc-ecosystem/grpc-gateway/v2/runtime"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	gw "grpc-gateway/myservice2/myservice2" // Update
)

var (
	// command-line options:
	// gRPC server endpoint
	grpcServerEndpoint = flag.String("grpc-server-endpoint", "localhost:50051", "gRPC server endpoint")
)

func run() error {
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// Register gRPC server endpoint
	// Note: Make sure the gRPC server is running properly and accessible
	mux := runtime.NewServeMux()
	mux.HandlePath("GET", "/ping", pingHandler)
	mux.HandlePath("POST", "/upload/file", uploadHandler)
	opts := []grpc.DialOption{grpc.WithTransportCredentials(insecure.NewCredentials())}
	err := gw.RegisterMyService2HandlerFromEndpoint(ctx, mux, *grpcServerEndpoint, opts)
	if err != nil {
		return err
	}

	// Start HTTP server (and proxy calls to gRPC server endpoint)
	return http.ListenAndServe(":8081", mux)
}

func main() {
	flag.Parse()
	defer glog.Flush()

	if err := run(); err != nil {
		glog.Fatal(err)
	}
}
func pingHandler(w http.ResponseWriter, r *http.Request, pathParams map[string]string) {
	fmt.Fprintf(w, "{\"msg\":\"pong\"}")
}
func uploadHandler(w http.ResponseWriter, r *http.Request, pathParams map[string]string) {
	err := r.ParseForm()
	if err != nil {
		http.Error(w, fmt.Sprintf("failed to parse form: %s", err.Error()), http.StatusBadRequest)
		return
	}

	f, header, err := r.FormFile("attachment")
	if err != nil {
		http.Error(w, fmt.Sprintf("failed to get file 'attachment': %s", err.Error()), http.StatusBadRequest)
		return
	}
	defer f.Close()

	conn, err := grpc.Dial(*grpcServerEndpoint, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Println(err)
		http.Error(w, fmt.Sprintf("failed conn to grpc : %s", err.Error()), http.StatusInternalServerError)
		return
	}
	defer conn.Close()
	c := pb.NewMyService2Client(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*30)
	defer cancel()
	ctx = metadata.NewOutgoingContext(ctx, metadata.New(map[string]string{"file_name": header.Filename}))
	stream, err := c.EchoUpload(ctx)
	if err != nil {
		log.Println(err)
		http.Error(w, fmt.Sprintf("failed conn to grpc : %s", err.Error()), http.StatusInternalServerError)
		return
	}

	buf := make([]byte, 100)
	for {
		n, err := f.Read(buf)
		if err != nil && err != io.EOF {
			log.Println(err)
			http.Error(w, fmt.Sprintf("failed to get file 'attachment': %s", err.Error()), http.StatusInternalServerError)
			return
		}
		if n == 0 {
			break
		}
		stream.Send(&pb.UploadRequest{
			Content: buf[:n],
			Size:    int64(n),
		})
	}
	res, err := stream.CloseAndRecv()
	if err != nil {
		log.Println(err)
		http.Error(w, fmt.Sprintf("failed to get file 'attachment': %s", err.Error()), http.StatusInternalServerError)
		return
	}
	fmt.Fprintf(w, res.Path)
	//fmt.Println(header.Filename)
}
