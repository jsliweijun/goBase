package router

import (
	"gin/middleware"
	"github.com/gin-gonic/gin"
)

func InitRouters(r *gin.Engine) {
	r.Use(middleware.LogInput)
	InitApi(r)
	InitCourse(r)
}
