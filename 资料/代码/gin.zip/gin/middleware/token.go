package middleware

import (
	"errors"
	"github.com/gin-gonic/gin"
	"net/http"
)

var token = "123456"

func TokenCheck(c *gin.Context) {
	acceessToken := c.GetHeader("access_token")
	if acceessToken != token {
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "token 校验失败",
		})
		c.AbortWithError(http.StatusInternalServerError, errors.New("token checker fail"))
	}
	c.Set("user_name", "nick")
	c.Set("user_id", "100")

	c.Next()
}
