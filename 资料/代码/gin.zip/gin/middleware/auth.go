package middleware

import (
	"fmt"
	"github.com/gin-gonic/gin"
)

func AuthCheck(c *gin.Context) {
	userId, _ := c.Get("user_id")
	userName := c.GetString("user_name")
	fmt.Printf("auth check called, userID: %v,userName:%s\n", userId, userName)
	c.Next()
}
