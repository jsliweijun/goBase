package fileOp

import (
	"io"
	"os"
	"path"
)

func CopyAllFileToDest() {
	list := getAllFile(sourceFile)
	for _, l := range list {
		_, name := path.Split(l)
		destFileName := destFile + "copy/" + name
		CopyFile(l, destFileName)
	}
}

func CopyFile(srcName, destName string) (int64, error) {
	src, _ := os.Open(srcName)
	defer src.Close()
	destName = "E:/Work/Code/go/tcp/upload/GeneralBasicOCR1.jpg"
	dst, _ := os.OpenFile(destName, os.O_CREATE|os.O_WRONLY, 0644)
	defer dst.Close()
	return io.Copy(dst, src)
}
