package fileOp

import (
	"io/ioutil"
	"path"
	"sync"
)

func ReadWriteFilesByGoRoutine() {
	wg := &sync.WaitGroup{}
	list := getAllFile(sourceFile)
	for _, fileName := range list {
		wg.Add(1)
		go func(wg *sync.WaitGroup, fileName string) {
			defer wg.Done()
			bytes, _ := ioutil.ReadFile(fileName)
			_, name := path.Split(fileName)
			ioutil.WriteFile(destFile+"goroutine/"+name, bytes, 0644)
		}(wg, fileName)
	}
	wg.Wait()
}
