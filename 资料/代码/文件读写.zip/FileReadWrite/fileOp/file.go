package fileOp

import (
	"io/ioutil"
	"log"
	"strings"
)

const sourceFile = "sourceFile/"
const destFile = "destFile/"

func getAllFile(dir string) []string {
	fs, err := ioutil.ReadDir(dir)
	if err != nil {
		log.Println(err)
		return nil
	}
	list := make([]string, 0)
	for _, fi := range fs {
		if !fi.IsDir() {
			fullName := strings.Trim(dir, "/") + "/" + fi.Name()
			list = append(list, fullName)
		}
	}
	return list
}
