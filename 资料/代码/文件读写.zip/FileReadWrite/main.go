package main

import (
	"FileReadWrite/fileOp"
	"FileReadWrite/yaml"
	"fmt"
	"log"
	"os"
)

func main() {
	log.Println("log log log")
	f, _ := os.OpenFile("destFile/log.log", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	log.SetOutput(f)
	log.Println("log log log")

	fileOp.CopyAllFileToDest()
	/*
		fileOp.ReadWriteFiles()
		fileOp.ReadWriteFilesByGoRoutine()
		fileOp.OneSideReadWriteToDest()
	*/
	//yaml.GetConfig()
	conf := yaml.LoadPath("configs/config.yaml")
	fmt.Println(conf.GetString("devices[0].nodes[0].index"))
	fmt.Println(conf.GetInt("devices[0].nodes[0].index"))

}
